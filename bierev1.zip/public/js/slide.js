/*let lastqueue = document.querySelector(".slideshow__element--lastqueue");
let last = document.querySelector(".slideshow__element--last");
let main = document.querySelector(".slideshow__element--main");
let next = document.querySelector(".slideshow__element--next");
let nextqueue = document.querySelector(".slideshow__element--nextqueue");

next.addEventListener('click', function(){
    
    nextqueue.className += " slideshow__element--next";
    next.className += " slideshow__element--main";
    main.className += " slideshow__element--last";
    last.className += " slideshow__element--lastqueue";


    nextqueue.classList.remove('slideshow__element--nextqueue');
    next.classList.remove('slideshow__element--next');
    main.classList.remove('slideshow__element--main');
    last.classList.remove('slideshow__element--last');
    lastqueue.classList.remove('slideshow__element--lastqueue');
});



last.addEventListener('click', function(){
    
    next.className += " slideshow__element--nextqueue";
    main.className += " slideshow__element--next";
    last.className += " slideshow__element--main";
    lastqueue.className += " slideshow__element--last"


    nextqueue.classList.remove('slideshow__element--nextqueue');
    next.classList.remove('slideshow__element--next');
    main.classList.remove('slideshow__element--main');
    last.classList.remove('slideshow__element--last');
    lastqueue.classList.remove('slideshow__element--lastqueue');
});*/