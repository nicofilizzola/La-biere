let transitionBlockIn = document.querySelector('.transition--in');
window.addEventListener('load', function(){
	transitionBlockIn.className += ' transition--play';
});
