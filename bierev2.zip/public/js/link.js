let links = document.querySelectorAll('footer a');

/*for (i = 0; i < links.length; i++){
    
    links[i].addEventListener('click', function(){
        //event.preventDefault();
        setTimeout(transStart(), 500);
        event.defaultPrevented == true;
    });
}*/

window.addEventListener('beforeunload', function(){
    event.preventDefault;
    setTimeout(transStart(),500);
    event.defaultPrevented = false;
})
