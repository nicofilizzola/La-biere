let audio = $('audio')[0];

$('#audio').hover(function(){
    audio.play();
});
