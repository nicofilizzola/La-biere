<!DOCTYPE HTML>
		<html>
			<head>
				<meta name="viewport" content="width=device-width, initial-scale=1.0">
				<link rel="icon" type="image/png" href="public/img/site-logo.png">
                <title>La Bière</title>
                <link rel="stylesheet" type="text/css" href="public/css/style.css">
			</head>

            <body>
                <div class="flex--col bg-black">
                    <h1>Mentions Légales</h1>
                    <br>
                    <h2>Identité</h2>
                    <p>Nom du site web : LeSiteDeLaBière</p>
                    <p>Adresse : http://lesitedelabiere.nicofilizzola.com/</p>
                    <p>Propriétaire : Nicolás Filizzola</p>
                    <p>Responsable de publication : Nicolás Filizzola</p>
                    <p>Conception et réalisation : Nicolás Filizzola, Émeric Charpentier, Maêl Gianni</p>
                    <p>Animation : Nicolás Filizzola</p>
                    <p>Hébergement : GoDaddy</p>
                <br>
                    <h2>Conditions d’utilisation</h2>
                    <p>L’utilisation du présent site implique l’acceptation pleine et entière des conditions générales d’utilisation décrites ci-après. Ces conditions d’utilisation sont susceptibles d’être modifiées ou complétées à tout moment.</p>
                <br>
                    <h2>Informations</h2>
                    <p>Les informations et documents du site sont présentés à titre indicatif, ne revêtent pas un caractère exhaustif, et ne peuvent engager la responsabilité du propriétaire du site.</p>
                    <p>Le propriétaire du site ne peut être tenu responsable des dommages directs et indirects consécutifs à l’accès au site.</p>
                <br>
                    <h2>Interactivité</h2>
                    <p>Les utilisateurs du site peuvent éventuellement y déposer du contenu, apparaissant sur le site dans des espaces dédiés (notamment via les commentaires). Le contenu déposé reste sous la responsabilité de leurs auteurs, qui en assument pleinement l’entière responsabilité juridique.</p>
                    <p>Le propriétaire du site se réserve le droit de retirer sans préavis et sans justification tout contenu déposé par les utilisateurs qui ne satisferait pas à la charte déontologique du site ou à la législation en vigueur.</p>
                <br>
                    <h2>Propriété intellectuelle</h2>
                    <p>Sauf mention contraire, tous les éléments accessibles sur le site (textes, images, graphismes, logo, icônes, sons, logiciels, etc.) restent la propriété exclusive de leurs auteurs, en ce qui concerne les droits de propriété intellectuelle ou les droits d’usage.</p>
                    <p>Toute reproduction, représentation, modification, publication, adaptation de tout ou partie des éléments du site, quel que soit le moyen ou le procédé utilisé, est interdite, sauf autorisation écrite préalable de l’auteur.</p>
                    <p>Toute exploitation non autorisée du site ou de l’un quelconque des éléments qu’il contient est considérée comme constitutive d’une contrefaçon et peut être poursuivie en justice.</p>
                    <p>Les marques et logos reproduits sur le site sont déposés par le propriétaire.</p>
                <br>
                    <h2>Liens</h2>
                    <p><b>Liens sortants</b></p>
                    <p>Le propriétaire du site décline toute responsabilité et n’est pas engagé par le référencement via des liens hypertextes, de ressources tierces présentes sur le réseau Internet, tant en ce qui concerne leur contenu que leur pertinence.</p>
                    <p><b>Liens entrants</b></p>
                    <p>Le propriétaire du site autorise les liens hypertextes vers l’une des pages de ce site, à condition que ceux-ci ouvrent une nouvelle fenêtre et soient présentés de manière non équivoque afin d’éviter :</p>
                    <p>- tout risque de confusion entre le site citant et le propriétaire du site,</p>
                    <p>- ainsi que toute présentation tendancieuse, ou contraire aux lois en vigueur.</p>
                    <p>Le propriétaire du site se réserve le droit de demander la suppression d’un lien s’il estime que le site source ne respecte pas les règles ainsi définies.</p>
                <br>
                    <h2>Confidentialité</h2>
                    <p>Tout utilisateur dispose d’un droit d’accès, de rectification et d’opposition aux données personnelles le concernant, en effectuant sa demande écrite et signée, accompagnée d’une preuve d’identité.</p>
                    <p>Le site ne recueille pas d’informations personnelles, et n’est pas assujetti à déclaration à la CNIL.</p>
                <br>
                    <h2>Crédits</h2>
                    <p><b>Photos :</b></p>
                    <p> Will Stewart on Unsplash</p>
                    <p> ANIRUDH on Unsplash</p>
                    <p> Stella de Smit on Unsplash</p>
                    <p> Paweł Czerwiński on Unsplash</p>
                    <p> Bermix Studio on Unsplash</p>
                    <p> Anomaly on Unsplash</p>
                    <p> Kyle Glenn on Unsplash</p>
                    <p> Timothy Dykes on Unsplash</p>
                    <p> Alban Martel on Unsplash</p>
                    <p> Evan Dvorkin on Unsplash</p>
                    <p> rashid khreiss on Unsplash</p>
                    <p> Elevate on Unsplash</p>
                    <p> Elevate on Unsplash</p>
                    <p> Eiliv-Sonas Aceron on Unsplash</p>
                    <p> Peter Dawn on Unsplash</p>
                    <p> Sal Gh on Unsplash</p>
                    <p> Lutz Wernitz on Unsplash</p>
                    <p> Toby Stodart on Unsplash</p>
                    <p> Alexander Dinamarca on Unsplash</p>
                    <p> Tomáš Malík on Unsplash</p>
                    <p> Hans Vivek on Unsplash</p>
                    <p> radovan on Unsplash</p>
                    <p>Photo <a href="https://www.la-french-bulldog.fr/wp-content/uploads/2015/09/Craft-brewery-la-french-bulldog-comment-brasser-biere-10.jpg">"empâtage"</a></p>
                    <p>Photo <a href="https://www.pinterest.fr/pin/356277020498665544/">"Houblonnage"</a></p>
                    <p>Photo <a href="https://www.stickpng.com/fr/img/nourriture/biere/pinte-de-biere-a-bulles">beer home</a></p>
                    <p>Sound <a href="https://lasonotheque.org/detail-1391-biere-service.html">Beer</a> Free</p>
                    <p>Video <a href="https://www.youtube.com/watch?v=mE7qjzkLTEg">"bière abbayes"</a></p>
                    <p><b>Références</b></p>
                    <p><a href="https://www.histoire-pour-tous.fr/dossiers/3558-histoire-de-la-biere-1-lantiquite.html">"La bière dans l'antiquité"</a> and <a href="https://www.brasseurs-de-france.com/tout-savoir-sur-la-biere/histoire/">"Histoire de la bière"</a></p>
                    <p><a href="https://fr.wikipedia.org/wiki/Bi%C3%A8re">Wikipedia page</a></p>
                    <p><a href="https://fr.wikipedia.org/wiki/Fabrication_de_la_bi%C3%A8re">Wikipedia page Fabrication</a></p>
                    <p><u>Le Figaro</u><a href="https://avis-vin.lefigaro.fr/biere/biere-artisanale/o140848-fabrication-de-la-biere-les-principales-etapes-ma-biere-artisanale">"Fabrication de la bière"</a></p>
                    <p>Video <a href="https://www.youtube.com/watch?v=DvzwxVwsjfQ">"La Fabrication de la Bière"</a></p>
                    <p>Video <a href="https://www.youtube.com/watch?v=Ouy2ocDbFYs">"C'est pas sorcier - BIERE"</a></p>
                    <p>Insee <a href="https://www.insee.fr/fr/statistiques/4319377#graphique-figure1"></a>"Les dépenses des ménages en boissons depuis 1960 - Insee Première - 1794"</p>
                    <p><a href="https://www.planetoscope.com/boisson/1162-consommation-mondiale-de-biere.html">Mondial beer instant statistics</a></p>
                    <p><a href="https://www.planetoscope.com/boisson/954-consommation-de-biere-en-france.html">France beer instant statistics</a></p>
                    <p><a href="https://fr.wikipedia.org/wiki/Saccharomyces_cerevisiae#%C3%89tymologie">Wikipedia page Saccharomyces cerevisiae</a></p>
                    <p><a href="https://www.brasseurs-de-france.com/tout-savoir-sur-la-biere/les-types-de-biere/">Types of beers</a></p>
                    <p><a href="https://www.rolling-beers.fr/fr/content/14-comment-faire-sa-propre-biere-maison">Do your own beer</a></p>
                    
                    <p>Mentions légales fournies par WebExpress – Version 1.5 – Utilisation libre sous Licence Creative Commons CC BY-NC-ND 3.0 FR / creativecommons.org</p>

            </div>

            <?php
                include('public/php/footer.php');
            ?>
